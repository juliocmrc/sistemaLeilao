import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Teste {

	@Test
	void test() {
		var managePessoa = new br.edu.ifg.database.ManagePessoa();
		assertEquals(false, managePessoa.removePessoa("12345678978"));
	}

}
