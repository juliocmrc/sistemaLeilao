package br.edu.ifg.databasetest;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import br.edu.ifg.database.Database;
import br.edu.ifg.database.ManageLance;
import br.edu.ifg.database.ManageLeilao;
import br.edu.ifg.entidades.Lance;
import br.edu.ifg.entidades.Leilao;

class ManageLanceTest {

	@Test
	void testListLance() {	
		var lance = new Lance();
		assertEquals(true, ManageLance.listaLances().add(lance));
	}
	
	@Test
	void testRemoveLance(){
		assertEquals(true, ManageLance.removeLance("12345678997"));
	}
	
	@Test
	void testInsertLance(){
		var lance = new Lance("Juliana Cruz", "12345678997", "PS5", 4200.00);
		assertEquals(true, ManageLance.insereLance(lance));
	}
}
