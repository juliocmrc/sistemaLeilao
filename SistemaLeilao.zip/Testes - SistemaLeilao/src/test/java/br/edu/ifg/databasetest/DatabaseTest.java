package br.edu.ifg.databasetest;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import br.edu.ifg.database.Database;

class DatabaseTest {

	@Test
	void test() throws SQLException {
		Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SistemaLeilao","postgres","22042003");
		assertEquals(connect, Database.createConnection().equals(null));
	}

}
