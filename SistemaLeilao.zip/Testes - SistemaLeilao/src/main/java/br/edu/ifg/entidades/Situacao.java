package br.edu.ifg.entidades;

public enum Situacao {
	
	FECHADO, ABERTO, LIQUIDADO;

}
